public class StudentRecord {

	// Write your code here.
	
}
