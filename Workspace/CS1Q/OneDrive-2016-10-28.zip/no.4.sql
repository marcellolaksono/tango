SELECT ExamMarks
FROM StudentCourseAssignments 
WHERE course="7ZFG"