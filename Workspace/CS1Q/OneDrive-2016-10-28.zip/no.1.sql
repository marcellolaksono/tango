SELECT forename, surname
FROM Student 
WHERE matricno = 1238000 