SELECT FirstName, Surname
FROM Staff 
WHERE NOT Status ="lecturers"