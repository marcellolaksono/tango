public class EanChecksum {
	public static void main(String[] args) {
		// Read the barcode from the user
		java.util.Scanner stdin = new java.util.Scanner(System.in);
		System.out.println("Enter the barcode number: ");
		String barcode = stdin.next();
		stdin.close();
		
		// TODO: Implement your code here
	}

}
